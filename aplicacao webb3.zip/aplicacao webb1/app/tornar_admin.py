from app.db import GerenciadorBanco

username = input("Digite seu nome de usuário: ")

with GerenciadorBanco() as banco:
    cursor = banco.cursor()

    cursor.execute("""
        UPDATE usuarios
        SET tipo = 'admin'
        WHERE username = ?
    """, (username,))

    if cursor.rowcount > 0:
        print("Conta transformada em administrador!")
    else:
        print("Usuário não encontrado.")