
from app.db import GerenciadorBanco


def iniciar_banco():

    # Abre a conexão com o banco
    with GerenciadorBanco() as banco:

        cursor = banco.cursor()

        # Cria a tabela de usuários
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL DEFAULT '',
                username TEXT NOT NULL UNIQUE,
                email TEXT UNIQUE,
                password_hash TEXT NOT NULL,
                tipo TEXT NOT NULL DEFAULT 'usuario'
            )
        """)

        cursor.execute("""
            CREATE TABLE animais (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                especie TEXT NOT NULL,
                idade INTEGER NOT NULL,
                descricao TEXT,
                disponivel INTEGER NOT NULL DEFAULT 1,
                foto TEXT
            )
        """)


if __name__ == "__main__":
    iniciar_banco()
