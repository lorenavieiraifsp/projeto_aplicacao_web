from app.db import GerenciadorBanco
 

class Animal:
    #estrutura do animal
    def __init__(
        self,
        nome,
        especie,
        idade,
        descricao="",
        disponivel=1,
        foto = None,
        id=None
    ):
        self.id = id
        self.nome = nome
        self.especie = especie
        self.idade = idade
        self.descricao = descricao
        self.disponivel = disponivel
        self.foto = foto

    def salvar(self):
        with GerenciadorBanco() as banco:
            cursor = banco.cursor()

            cursor.execute("""
                INSERT INTO animais (nome, especie, idade, descricao, disponivel, foto)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                self.nome,
                self.especie,
                self.idade,
                self.descricao,
                self.disponivel,
                self.foto
            ))

    @classmethod
    def listar_todos(cls):
        with GerenciadorBanco() as banco:
            cursor = banco.cursor()

            cursor.execute("""
                SELECT * FROM animais
            """)

            animais = cursor.fetchall()

            return animais


    @classmethod
    def listar_disponiveis(cls):
        with GerenciadorBanco() as banco:
            cursor = banco.cursor()

            cursor.execute("""
                SELECT * FROM animais
                WHERE disponivel = 1
            """)

            animais = cursor.fetchall()

            return animais