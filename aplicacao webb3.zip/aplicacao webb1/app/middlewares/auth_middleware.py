
from flask import request, session, redirect, url_for


def auth_middleware():

    # Rotas que podem ser acessadas sem login
    rotas_publicas = [
        "login.login",
        "login.cadastro",
        "login.logout",
        "home.home",
        "static"
    ]

    # Descobre a rota que a pessoa está tentando acessar
    rota_atual = request.endpoint

    # Permite acessar rotas públicas
    if rota_atual in rotas_publicas:
        return None

    # Verifica se a pessoa está logada
    if "usuario" not in session:
        return redirect(url_for("login.login"))

    # Verifica se a rota pertence à área administrativa
    rotas_admin = [
        "animal.cadastrar_animal",
         "admin.painel_admin"
    ]

    if rota_atual in rotas_admin and session.get("tipo") != "admin":
        return redirect(url_for("home.area_usuario"))

    return None
