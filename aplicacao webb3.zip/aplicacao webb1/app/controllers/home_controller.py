from flask import Blueprint, render_template, session
from app.models.animais import Animal


home_controller = Blueprint("home", __name__)


@home_controller.route("/")
def home():
    return render_template("home.html")


@home_controller.route("/area-usuario")
def area_usuario():

    nome_usuario = session.get("usuario")
    tipo_usuario = session.get("tipo")

    animais = Animal.listar_disponiveis()

    return render_template(
        "area_usuario.html",
        nome_usuario=nome_usuario,
        tipo_usuario=tipo_usuario,
        animais=animais
    )