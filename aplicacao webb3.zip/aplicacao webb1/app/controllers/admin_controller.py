from flask import Blueprint, render_template, session

admin_controller = Blueprint("admin", __name__)


@admin_controller.route("/admin")
def painel_admin():

    nome_usuario = session.get("usuario")

    return render_template(
        "area_admin.html",
        nome_usuario=nome_usuario
    )