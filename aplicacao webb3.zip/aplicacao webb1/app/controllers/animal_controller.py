from flask import Blueprint,  render_template, request, redirect, url_for, current_app
from app.models.animais import Animal
import uuid 
import os
from werkzeug.utils import secure_filename

animal_controller = Blueprint("animal", __name__)

# Rota para cadastrar animais
@animal_controller.route("/animais/cadastrar", methods=["GET", "POST"])
def cadastrar_animal():

    if request.method == "POST":

        nome = request.form.get("nome")
        especie = request.form.get("especie")
        idade = request.form.get("idade")
        descricao = request.form.get("descricao") 
        arquivo = request.files.get("foto")
        nome_foto = None

        if arquivo and arquivo.filename:
            extensao = os.path.splitext(arquivo.filename)[1].lower()

            if extensao not in [".jpg", ".jpeg", ".png", ".webp"]:
                return render_template(
                    "cadastrar_animal.html",
                    erro="Envie uma imagem JPG, PNG ou WEBP."
                )

            nome_arquivo = secure_filename(
                uuid.uuid4().hex + extensao
            )

            pasta_uploads = os.path.join(
                current_app.static_folder,
                "uploads"
            )

            os.makedirs(pasta_uploads, exist_ok=True)

            caminho = os.path.join(pasta_uploads, nome_arquivo)
            arquivo.save(caminho)

            nome_foto = "uploads/" + nome_arquivo

        novo_animal = Animal(
            nome=nome,
            especie=especie,
            idade=int(idade),
            descricao=descricao,
            foto=nome_foto
        )

        novo_animal.salvar()

        return redirect(url_for("animal.listar_animais"))

    return render_template("cadastrar_animal.html")

# Rota para listar animais disponíveis
@animal_controller.route("/animais")
def listar_animais():

    animais = Animal.listar_todos()

    return render_template(
        "listar_animais.html",
        animais=animais
    )
