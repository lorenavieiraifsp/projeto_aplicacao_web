from app.db import GerenciadorBanco

with GerenciadorBanco() as banco:
    cursor = banco.cursor()

    cursor.execute("""
        SELECT name FROM sqlite_master
        WHERE type = 'table'
    """)

    tabelas = cursor.fetchall()

    for tabela in tabelas:
        print(tabela["name"])