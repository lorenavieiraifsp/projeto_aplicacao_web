
import sqlite3

conexao = sqlite3.connect("app/banco.db")
cursor = conexao.cursor()

# Mostra as tabelas existentes no banco
cursor.execute("""
    SELECT name
    FROM sqlite_master
    WHERE type = 'table'
""")

tabelas = cursor.fetchall()
print("Tabelas encontradas:", tabelas)

# Mostra as colunas da tabela usuarios, se ela existir
if ("usuarios",) in tabelas:
    cursor.execute("PRAGMA table_info(usuarios)")
    print("Colunas:", cursor.fetchall())

conexao.close()
