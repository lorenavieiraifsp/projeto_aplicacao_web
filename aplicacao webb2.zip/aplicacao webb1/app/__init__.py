from flask import Flask


def create_app():

    app = Flask(
        __name__,
        template_folder="views"
    )

    # Chave usada para proteger os dados da sessão.
    # Em um projeto real, essa chave deve ficar em uma variável de ambiente.
    app.secret_key = "chave-secreta-do-projeto"

    # Importa o middleware responsável pela autenticação
    from app.middlewares.auth_middleware import auth_middleware

    # Registra o middleware
    app.before_request(auth_middleware)

    # Importa os Blueprints
    from app.controllers.login_controller import login_controller
    from app.controllers.home_controller import home_controller

    # Registra os Blueprints
    app.register_blueprint(login_controller)
    app.register_blueprint(home_controller)

    return app