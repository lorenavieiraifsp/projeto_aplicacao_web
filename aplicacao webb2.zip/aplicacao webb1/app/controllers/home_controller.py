from flask import Blueprint, render_template, session


home_controller = Blueprint(
    "home",
    __name__
)


@home_controller.route("/")
def home():

    return render_template("home.html")


@home_controller.route("/area-usuario")
def area_usuario():

    # Pega o nome armazenado na sessão
    nome_usuario = session.get("usuario")

    # Pega o tipo armazenado na sessão
    tipo_usuario = session.get("tipo")

    return render_template(
        "area_usuario.html",
        nome_usuario=nome_usuario,
        tipo_usuario=tipo_usuario
    )