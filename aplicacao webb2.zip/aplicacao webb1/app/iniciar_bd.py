
from app.db import GerenciadorBanco


def iniciar_banco():

    # Abre a conexão usando o Context Manager
    with GerenciadorBanco() as banco:

        cursor = banco.cursor()

        # Cria a tabela caso ela ainda não exista
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL DEFAULT '',
                username TEXT NOT NULL UNIQUE,
                email TEXT UNIQUE,
                password_hash TEXT NOT NULL,
                tipo TEXT NOT NULL DEFAULT 'usuario'
            )
        """)

        # Consulta as colunas que existem atualmente na tabela
        cursor.execute("PRAGMA table_info(usuarios)")
        colunas = [coluna["name"] for coluna in cursor.fetchall()]

        # Adiciona nome se a tabela antiga ainda não tiver essa coluna
        if "nome" not in colunas:
            cursor.execute("""
                ALTER TABLE usuarios
                ADD COLUMN nome TEXT NOT NULL DEFAULT ''
            """)

        # Adiciona email se a tabela antiga ainda não tiver essa coluna
        if "email" not in colunas:
            cursor.execute("""
                ALTER TABLE usuarios
                ADD COLUMN email TEXT
            """)


if __name__ == "__main__":
    iniciar_banco()
