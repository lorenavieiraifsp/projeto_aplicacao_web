import sqlite3
import os


class GerenciadorBanco:

    def __init__(self):

        # Define o caminho da pasta app
        base_dir = os.path.dirname(os.path.abspath(__file__))

        # Define o caminho do banco de dados
        self.db_path = os.path.join(base_dir, "banco.db")

        # A conexão começa vazia
        self.conn = None


    def __enter__(self):

        # Abre a conexão com o banco
        self.conn = sqlite3.connect(self.db_path)

        # Permite acessar as colunas pelo nome
        self.conn.row_factory = sqlite3.Row

        # Retorna a conexão para o bloco with
        return self.conn


    def __exit__(self, tipo_erro, valor_erro, traceback):

        # Se não aconteceu nenhum erro, confirma as alterações
        if tipo_erro is None:
            self.conn.commit()

        # Se aconteceu algum erro, desfaz as alterações
        else:
            self.conn.rollback()

        # Fecha a conexão
        self.conn.close()