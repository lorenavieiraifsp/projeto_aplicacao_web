
from werkzeug.security import generate_password_hash, check_password_hash

from app.db import GerenciadorBanco


class Usuario:

    def __init__(
        self,
        username,
        password_hash,
        nome="",
        email=None,
        tipo="usuario",
        id=None
    ):
        # Guarda os dados do usuário no objeto
        self.id = id
        self.nome = nome
        self.username = username
        self.email = email
        self.password_hash = password_hash
        self.tipo = tipo

    @classmethod
    def buscar_por_username(cls, username):

        # Abre a conexão com o banco
        with GerenciadorBanco() as banco:
            cursor = banco.cursor()

            # Busca o usuário pelo nome de usuário
            cursor.execute("""
                SELECT id, nome, username, email, password_hash, tipo
                FROM usuarios
                WHERE username = ?
            """, (username,))

            registro = cursor.fetchone()

        # Se não encontrar, retorna None
        if registro is None:
            return None

        # Transforma o registro encontrado em um objeto Usuario
        return cls(
            id=registro["id"],
            nome=registro["nome"],
            username=registro["username"],
            email=registro["email"],
            password_hash=registro["password_hash"],
            tipo=registro["tipo"]
        )

    def verificar_senha(self, senha):

        # Compara a senha digitada com o hash armazenado
        return check_password_hash(self.password_hash, senha)

    def salvar(self, senha):

        # Gera o hash da senha antes de armazená-la
        self.password_hash = generate_password_hash(senha)

        # Abre a conexão com o banco
        with GerenciadorBanco() as banco:
            cursor = banco.cursor()

            # Insere os dados do novo usuário
            cursor.execute("""
                INSERT INTO usuarios
                    (nome, username, email, password_hash, tipo)
                VALUES (?, ?, ?, ?, ?)
            """, (
                self.nome,
                self.username,
                self.email,
                self.password_hash,
                self.tipo
            ))

            # Guarda o ID gerado pelo banco
            self.id = cursor.lastrowid
