
import sqlite3

from flask import Blueprint, render_template, request, redirect, url_for, session

from app.models.usuario import Usuario


login_controller = Blueprint("login", __name__)


@login_controller.route("/login", methods=["GET", "POST"])
def login():

    # Se o formulário foi enviado
    if request.method == "POST":

        # Pega os dados digitados no formulário
        nome_usuario = request.form.get("usuario")
        senha = request.form.get("senha")

        # Procura o usuário no banco
        usuario = Usuario.buscar_por_username(nome_usuario)

        # Verifica se o usuário existe e se a senha está correta
        if usuario and usuario.verificar_senha(senha):

            # Guarda as informações necessárias na sessão
            session["usuario"] = usuario.username
            session["tipo"] = usuario.tipo

            # Vai para a área protegida
            return redirect(url_for("home.area_usuario"))

        # Mostra uma mensagem se os dados estiverem incorretos
        return render_template(
            "login.html",
            erro="Usuário ou senha incorretos."
        )

    # Se for GET, mostra a tela de login
    return render_template("login.html")


@login_controller.route("/cadastro", methods=["GET", "POST"])
def cadastro():

    # Se o formulário de cadastro foi enviado
    if request.method == "POST":

        # Pega os dados preenchidos no formulário
        nome = request.form.get("nome", "").strip()
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        senha = request.form.get("senha", "")
        confirmar_senha = request.form.get("confirmar_senha", "")

        # Verifica se todos os campos foram preenchidos
        if not nome or not username or not email or not senha:
            return render_template(
                "cadastro.html",
                erro="Preencha todos os campos."
            )

        # Confere se as senhas são iguais
        if senha != confirmar_senha:
            return render_template(
                "cadastro.html",
                erro="As senhas não coincidem."
            )

        # Verifica se o nome de usuário já está cadastrado
        if Usuario.buscar_por_username(username):
            return render_template(
                "cadastro.html",
                erro="Esse nome de usuário já está cadastrado."
            )

        # Cria o objeto com os dados da nova conta
        novo_usuario = Usuario(
            nome=nome,
            username=username,
            email=email,
            password_hash="",
            tipo="usuario"
        )

        try:
            # Salva a conta no banco e protege a senha com hash
            novo_usuario.salvar(senha)

        except sqlite3.IntegrityError:
            # Pode acontecer se o e-mail já estiver cadastrado
            return render_template(
                "cadastro.html",
                erro="Esse nome de usuário ou e-mail já está cadastrado."
            )

        # Entra na conta depois do cadastro
        session["usuario"] = novo_usuario.username
        session["tipo"] = novo_usuario.tipo

        # Vai para a área de adoção
        return redirect(url_for("home.area_usuario"))

    # Se for GET, mostra a página de cadastro
    return render_template("cadastro.html")


@login_controller.route("/logout")
def logout():

    # Remove os dados do usuário da sessão
    session.clear()

    # Volta para a tela de login
    return redirect(url_for("login.login"))
