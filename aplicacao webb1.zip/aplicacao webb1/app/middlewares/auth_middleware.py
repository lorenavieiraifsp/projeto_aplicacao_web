
from flask import request, session, redirect, url_for


def auth_middleware():

    # Rotas que podem ser acessadas sem estar logado
    rotas_publicas = [
        "login.login",
        "login.cadastro",
        "login.logout",
        "home.home",
        "static"
    ]

    # Descobre qual rota o usuário está tentando acessar
    rota_atual = request.endpoint

    # Se a rota for pública, deixa continuar
    if rota_atual in rotas_publicas:
        return None

    # Verifica se existe usuário na sessão
    if "usuario" not in session:

        # Se não estiver logado, manda para o login
        return redirect(url_for("login.login"))

    # Se estiver logado, permite continuar
    return None
